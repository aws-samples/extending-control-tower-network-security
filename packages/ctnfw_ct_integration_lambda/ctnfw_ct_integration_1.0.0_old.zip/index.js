const https = require('https');
const AWS = require('aws-sdk');
var sts = new AWS.STS();

var resp = {};


// Helper function to simulate a wait for getting status of the Stackset createInstance operation. 
function wait(ms = 1000) {
  return new Promise(resolve => {
    console.log(`waiting ${ms} ms...`);
    setTimeout(resolve, ms);
  });
}


// Method to check the status of CloudFormation Stackset createInstance operation
// In the callback it checks if  createInstance is successful and calls the method
// _verifymemberAccount to veirfy the member account with Cloudability.

async function _checkStackSetSuccess(event, context, secret, opId, callbackFunc) {

var params = {
  OperationId: opId, /* required */
  StackSetName: process.env.STACKSET_NAME, /* required */
};
var cloudformation = new AWS.CloudFormation();
  let result = 'PENDING';
  console.log("The status of Stackset operation first check is (0) ="+result);
  while (result === 'PENDING' || result === 'RUNNING') {
    await wait(1000);
    console.log("The status of Stackset operation first check is ="+result);
    await cloudformation.listStackSetOperationResults(params, function(err, data) {
      if (err) console.log(err, err.stack); // an error occurred
      else {
          console.log(data);           // successful response
          if(data.Summaries[0]) {
              
              console.log('listOperation status' + data.Summaries[0].Status);
              if (data.Summaries[0].Status === 'SUCCEEDED') {
                    console.log("StackSet Operation Succeeded");
              }
              result = data.Summaries[0].Status;
          }
          else
          console.log('listOperation status is unavailable'  );
      }
    });
  }

  return result;
}




// This function makes a call to CloudFormation StackSet createInstance with a parameter ovorride for 'externalId' 
// received from Cloudability API for the member account. It then checks the status of the operation in the callback
// through the method _checkStackSetSuccess
 
const _addSCLaunchRoleStackSetInstanceForMemberAccount = function(event, context, callbackFunc) {
    

    console.log("Stack set name is "+ process.env.STACKSET_NAME);
    let childAccountId = event.detail.serviceEventDetails.createManagedAccountStatus.account.accountId;
    console.log("Event Account ID is"+ childAccountId);
    var params = {
      Regions: [ /* required */
        process.env.AWS_REGION,
        /* more items */
      ],
      StackSetName: process.env.STACKSET_NAME, /* required */
      DeploymentTargets: {
        Accounts: [
          childAccountId,
          /* more items */
        ],
      },
    };

    console.log('Calling CF StackSet Update');
    var cloudformation = new AWS.CloudFormation();
    cloudformation.createStackInstances(params, function(err, data) {
      if (err) {
          console.log(err, err.stack); // an error occurred
          callbackFunc(err, err.stack);
          
      }
      else {
          console.log(data);           // successful response
          // Call listOPeration
          //data = JSON.stringify(data);
          console.log("The Stackset operation id is "+ data.OperationId);
         // _checkStackSetSuccess(event, context, data.OperationId, callbackFunc);

      }
    });
    
};

var response = (message, status) => {
    console.log("Message: " + message);
    return {
        statusCode: status,
        headers: {
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify({
          message: message
        }),
      };
  };

const _shareTGWToMemberAccount = function(event, context, callbackFunc) {
  
  //Assuming the new role will return temporary credentials
    var sts_params = {
      RoleArn: process.env.EXECUTION_ROLE_ARN,
      RoleSessionName: "ControlTowerExecutionRoleSession"
    };
  
    sts.assumeRole(sts_params, function (err, data) {
      if (err) {
        console.log(err, err.stack);
      } else {
        console.log(data);

        //Once we've gotten the temp credentials, let's apply them
        AWS.config.credentials = new AWS.TemporaryCredentials({RoleArn: sts_params.RoleArn});
        
        var ram = new AWS.RAM();
        let childAccountId = event.detail.serviceEventDetails.createManagedAccountStatus.account.accountId;
        console.log("The TGW ARN is "+process.env.TGW_ARN);
        var params = {
          name: 'tgwShare-'+childAccountId, /* required */
          allowExternalPrincipals: true,
          principals: [
            childAccountId
            /* more items */
          ],
          resourceArns: [
            process.env.TGW_ARN
            /* more items */
          ]
        };
        console.log("Sharing TGW to member account");
        ram.createResourceShare(params, function(err, data) {
        if (err) console.log(err, err.stack); // an error occurred
        else     console.log(data);           // successful response
        });
      }
    })
    
};

exports.handler =  (event, context, callback) => {
    
    
    
    _addSCLaunchRoleStackSetInstanceForMemberAccount(event, context, callback);
    _shareTGWToMemberAccount(event,context,callback);
    //_shareSCPortfolioToMemberAccount(event,context,callback);

};
